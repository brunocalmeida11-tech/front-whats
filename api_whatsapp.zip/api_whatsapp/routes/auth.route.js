const { Router } = require('express');

const router = Router();

router.post('/auth', (req, res) => {
    const { telefone, senha } = req.query;

    console.log('Telefone recebido:', telefone);
    console.log('Senha recebida:', senha ? 'Sim' : 'Não');

    res.json({
        message: 'Rota de autenticação',
        telefone: telefone
    });
});

module.exports = router;