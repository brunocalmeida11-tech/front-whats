const API = 'http://localhost:3000';

// CADASTRAR USUÁRIO
async function realizarRegistro() {
    const apelido = document.getElementById('regApelido').value;
    const telefone = document.getElementById('regTelefone').value;
    const senha = document.getElementById('regSenha').value;

    const dados = new FormData();
    dados.append('Apelido', apelido);
    dados.append('Telefone', telefone);
    dados.append('Senha', senha);

    try {
        const resposta = await fetch(`${API}/registrar`, {
            method: 'POST',
            body: dados
        });

        const resultado = await resposta.json();

        if (resposta.ok) {
            alert('Usuário cadastrado com sucesso!');
        } else {
            alert(JSON.stringify(resultado));
        }
    } catch (erro) {
        alert('Erro ao conectar com a API.');
        console.error(erro);
    }
}

// FAZER LOGIN
async function realizarLogin() {
    const telefone = document.getElementById('loginTelefone').value;
    const senha = document.getElementById('loginSenha').value;

    const url = `${API}/auth?Telefone=${encodeURIComponent(telefone)}&Senha=${encodeURIComponent(senha)}`;

    try {
        const resposta = await fetch(url, {
            method: 'POST'
        });

        const resultado = await resposta.json();

        if (resposta.ok) {
            sessionStorage.setItem('telefone', telefone);
            sessionStorage.setItem('senha', senha);

            alert('Login realizado com sucesso!');
        } else {
            alert(JSON.stringify(resultado));
        }
    } catch (erro) {
        alert('Erro ao conectar com a API.');
        console.error(erro);
    }
}

// ENVIAR MENSAGEM
async function enviarMensagem() {
    const destinatario = document.getElementById('destinatario').value;
    const mensagem = document.getElementById('textoMensagem').value;

    const telefone = sessionStorage.getItem('telefone');
    const senha = sessionStorage.getItem('senha');

    if (!telefone || !senha) {
        alert('Faça login antes de enviar mensagens.');
        return;
    }

    if (!destinatario || !mensagem) {
        alert('Preencha o destinatário e a mensagem.');
        return;
    }

    const url = `${API}/chat?Telefone=${encodeURIComponent(telefone)}&Senha=${encodeURIComponent(senha)}`;

    try {
        const resposta = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                telefone: destinatario,
                mensagem: mensagem
            })
        });

        const resultado = await resposta.json();

        if (resposta.ok) {
            alert('Mensagem enviada com sucesso!');
            document.getElementById('textoMensagem').value = '';
        } else {
            alert(JSON.stringify(resultado));
        }
    } catch (erro) {
        alert('Erro ao conectar com a API.');
        console.error(erro);
    }
}